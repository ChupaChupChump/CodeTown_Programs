# CodeTown_Programs
Python programs for an imaginary client called CodeTown


air_quality.py
    air_quality.py is a program made for Codetown as part of COSC110 Programming Task 1.
    The purpose of the program is to calculate AQI
    The AQI is calculated by the highest result from the 3 calculations for
	- Ozone
	- Sulfur Dioxide
	- Particles less than 2.5 micrometre diameter

    To run air_quality.py using a BASH terminal
        - Assure you are in the same directory as air_quality.py and this README.md file
        - run the command ./air_quality.py
